# import streamlit as st
# from langchain_community.document_loaders import WebBaseLoader

# from chains import Chain
# from portfolio import Portfolio
# from utils import clean_text


# def create_streamlit_app(llm, portfolio, clean_text):
#     st.title("📧 Cold Mail Generator")
#     url_input = st.text_input("Enter a URL:", value="https://jobs.nike.com/job/R-33460")
#     submit_button = st.button("Submit")

#     if submit_button:
#         try:
#             loader = WebBaseLoader([url_input])
#             data = clean_text(loader.load().pop().page_content)
#             portfolio.load_portfolio()
#             jobs = llm.extract_jobs(data)
#             for job in jobs:
#                 skills = job.get('skills', [])
#                 links = portfolio.query_links(skills)
#                 email = llm.write_mail(job, links)
#                 st.code(email, language='markdown')
#         except Exception as e:
#             st.error(f"An Error Occurred: {e}")


# if __name__ == "__main__":
#     chain = Chain()
#     portfolio = Portfolio()
#     st.set_page_config(layout="wide", page_title="Cold Email Generator", page_icon="📧")
#     create_streamlit_app(chain, portfolio, clean_text)

import streamlit as st
from langchain_community.document_loaders import WebBaseLoader
from chains import Chain
from portfolio import Portfolio
from utils import clean_text
import random


def create_streamlit_app(llm, portfolio, clean_text):
    # Configure Streamlit page
    st.set_page_config(layout="wide", page_title="Cold Email Generator", page_icon="📧")
    st.title("📧 Cold Mail Generator")

    # Maintain generated results in session
    if "email_results" not in st.session_state:
        st.session_state.email_results = []

    url_input = st.text_input("Enter a job URL:", value="https://jobs.nike.com/job/R-33460")
    submit_button = st.button("Generate Cold Emails")

    if submit_button:
        try:
            with st.spinner("🔍 Extracting job details and generating personalized emails..."):
                # Load and clean job data
                loader = WebBaseLoader([url_input])
                data = clean_text(loader.load().pop().page_content)

                # Load portfolio context
                portfolio.load_portfolio()

                # Extract job details using your LLM chain
                jobs = llm.extract_jobs(data)

                # ✅ Deduplicate job entries
                unique_jobs = []
                seen = set()
                for job in jobs:
                    identifier = (job.get('title', '').lower(), job.get('company', '').lower())
                    if identifier not in seen:
                        seen.add(identifier)
                        unique_jobs.append(job)
                jobs = unique_jobs

                # Handle empty job extraction
                if not jobs:
                    st.warning("⚠️ No valid job details found on this page.")
                    return

                # Generate up to 5 unique cold mails for each job
                generated_emails = []
                for job in jobs:
                    skills = job.get('skills', [])
                    links = portfolio.query_links(skills)

                    st.info(f"🧠 Generating up to 5 personalized emails for {job.get('title', 'this role')}...")

                    for i in range(5):
                        # Add slight variation to prompts for diversity
                        prompt_variant = f"Version {i+1}: " + random.choice([
                            "Make it concise and professional.",
                            "Make it a friendly and confident tone.",
                            "Focus on technical expertise and results.",
                            "Show enthusiasm and creativity.",
                            "Highlight teamwork and adaptability."
                        ])
                        email = llm.write_mail(job, links + [prompt_variant])
                        generated_emails.append({
                            "job_title": job.get("title", "Unknown Role"),
                            "version": i + 1,
                            "email": email
                        })

                # Store results
                st.session_state.email_results = generated_emails

        except Exception as e:
            st.error(f"❌ An Error Occurred: {e}")

    # Display results
    if st.session_state.email_results:
        st.subheader("📨 Generated Cold Emails (Max 5 per job)")
        for idx, email_data in enumerate(st.session_state.email_results, start=1):
            st.markdown(f"### ✉️ {email_data['job_title']} — Version {email_data['version']}")
            st.code(email_data['email'], language="markdown")

    # Optional: Add Regenerate button
    if st.session_state.email_results:
        if st.button("🔁 Regenerate New Set"):
            st.session_state.email_results = []
            st.rerun()


if __name__ == "__main__":
    chain = Chain()
    portfolio = Portfolio()
    create_streamlit_app(chain, portfolio, clean_text)




