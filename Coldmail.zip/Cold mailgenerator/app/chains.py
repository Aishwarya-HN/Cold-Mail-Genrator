import os
from langchain_groq import ChatGroq
from langchain_core.prompts import PromptTemplate
from langchain_core.output_parsers import JsonOutputParser
from langchain_core.exceptions import OutputParserException
from dotenv import load_dotenv

load_dotenv()

class Chain:
    def __init__(self):
        self.llm = ChatGroq(temperature=0, groq_api_key=os.getenv("GROQ_API_KEY"), model_name="llama-3.1-8b-instant")

    def extract_jobs(self, cleaned_text):
        prompt_extract = PromptTemplate.from_template(
            """
            ### SCRAPED TEXT FROM WEBSITE:
            {page_data}
            ### INSTRUCTION:
            The scraped text is from the career's page of a website.
            Your job is to extract the job postings and return them in JSON format containing the following keys: `role`, `experience`, `skills` and `description`.
            Only return the valid JSON.
            ### VALID JSON (NO PREAMBLE):
            """
        )
        chain_extract = prompt_extract | self.llm
        res = chain_extract.invoke(input={"page_data": cleaned_text})
        try:
            json_parser = JsonOutputParser()
            res = json_parser.parse(res.content)
        except OutputParserException:
            raise OutputParserException("Context too big. Unable to parse jobs.")
        return res if isinstance(res, list) else [res]

    def write_mail(self, job, links):
        prompt_email = PromptTemplate.from_template(
            """
            ### JOB DESCRIPTION:
         {job_description}
    
        ### LINKS / PORTFOLIO REFERENCES:
        {link_list}
    
        ### INSTRUCTION:
        You are Shashikala S, a 7th-semester B.E. student in Artificial Intelligence and Data Science at GSSSIETW.
        You have strong skills in coding, emerging technologies, communication, team collaboration, leadership, and public speaking.

        Write a cold email to a recruiter or hiring manager expressing interest in an internship or entry-level opportunity (without mentioning any specific job role).
        The email should highlight your technical skills and tech stack relevant to the company or project (based on the links provided by the user).
        Naturally incorporate the most relevant portfolio links ({link_list}) to demonstrate alignment with the company’s goals or technologies.
        Keep the tone professional, confident, and concise, showing enthusiasm for learning, innovation, and contributing to impactful projects. 
            Do not provide a preamble.
            ### EMAIL (NO PREAMBLE):

            """
        )
        chain_email = prompt_email | self.llm
        res = chain_email.invoke({"job_description": str(job), "link_list": links})
        return res.content

if __name__ == "__main__":
    print(os.getenv("GROQ_API_KEY"))